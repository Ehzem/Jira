# Manual actions and known Jira Cloud limitations

The exporter is deliberately tolerant: unsupported or inaccessible endpoints are written to `data/errors/` and listed in `reports/endpoint_status.csv`.

- Private filters that are not visible to the authenticated account cannot be exported by the filter search API.
- Board creation is exposed, but not every board setting has an equivalent public write API. The exporter now saves Jira's internal read-only Board settings edit model when available, but the importer must still flag settings that Jira does not expose through a supported write API.
- Jira's project/space List view can include personal browser-local display state, and newer Jira Cloud experiences also support admin-saved shared views. v1.5 snapshots Firefox localStorage as a fallback for the displayed personal state; shared saved-view configuration is not exposed by the documented board REST API and may still require a tenant-specific internal endpoint for exact recreation.
- Marketplace-app workflow validators, conditions, triggers, or post-functions may require the same app and app-specific configuration on the destination site.
- Users cannot be cloned as Jira accounts by this exporter. Destination users must be invited/provisioned, then mapped by account ID/email/display name where available.
- Passwords, API tokens, OAuth secrets, app licences, billing, organization policies, domains, and product-access settings are intentionally not exported.
- Team-managed project configuration is not represented by the same global schemes used by company-managed projects, so some settings may require manual recreation.
- The destination site may assign different IDs to every field, field context, field option, status, workflow, screen, scheme, filter, board, component, and version. The importer must remap references.
- Default values that reference users, groups, projects, or versions require destination mappings. The importer should report any value it cannot map safely.
- Firefox site storage was captured, but no ordered Jira field sequence was detected for the List view. The supported user-default columns API is still exported and will be evaluated as a fallback.
- TES: exact project/space List column order was not proven by browser state. Exporter retained jira_user_default_columns instead. Open TES List in Firefox, arrange the desired columns, keep that tab open, and re-run v1.9 on the same OS user. If Jira is using a shared saved view, its server-side view model may still require a tenant-specific internal endpoint.
